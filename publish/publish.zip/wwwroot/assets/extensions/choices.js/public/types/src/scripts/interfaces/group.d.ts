export interface Group {
    id?: number;
    active?: boolean;
    disabled?: boolean;
    value: any;
}
//# sourceMappingURL=group.d.ts.map